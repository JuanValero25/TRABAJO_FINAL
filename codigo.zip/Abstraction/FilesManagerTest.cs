﻿using Abstraction;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace MPP
{
    [TestClass]
    public class FilesManagerTest
    {


        [TestMethod]
        public void TestMethod1()
        {
            var asd = "asd";
            Console.WriteLine("algo"+asd);
        }
    }

    
}
